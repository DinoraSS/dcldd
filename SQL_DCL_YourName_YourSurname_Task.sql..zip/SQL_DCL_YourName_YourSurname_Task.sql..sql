-- Create a new user
CREATE USER rentaluser WITH PASSWORD 'rentalpassword';

-- Grant connect privilege to the user
GRANT CONNECT ON DATABASE dvdrental TO rentaluser;

-- Grant SELECT permission on the customer table to the user
GRANT SELECT ON customer TO rentaluser;

-- Check if the SELECT permission works correctly
SELECT * FROM customer;

-- Create a new user group
CREATE GROUP rental;

-- Add rentaluser to the rental group
GRANT rental TO rentaluser;

-- Grant INSERT and UPDATE permissions on the rental table to the rental group
GRANT INSERT, UPDATE ON rental TO rental;

-- Insert a new row into the rental table
INSERT INTO rental (rental_id, rental_date, inventory_id, customer_id, return_date)
VALUES (10000, '2023-11-26', 5000, 1, '2023-11-27');

-- Update an existing row in the rental table
UPDATE rental
SET return_date = '2023-11-28'
WHERE rental_id = 1;

-- Revoke INSERT permission on the rental table from the rental group
REVOKE INSERT ON rental FROM rental;

-- Try to insert a new row into the rental table (this should result in a permission denied error)
INSERT INTO rental (rental_id, rental_date, inventory_id, customer_id, return_date)
VALUES (10001, '2023-11-26', 5001, 2, '2023-11-27');

-- Create a personalized role for a customer
CREATE ROLE client_John_Doe;

-- Grant SELECT permission on the rental and payment tables to the personalized role
GRANT SELECT ON rental TO client_John_Doe;
GRANT SELECT ON payment TO client_John_Doe;

-- Assuming the customer's ID is 123
ALTER DEFAULT PRIVILEGES FOR ROLE client_John_Doe IN SCHEMA public
GRANT SELECT ON TABLE rental TO client_John_Doe;
GRANT SELECT ON TABLE payment TO client_John_Doe;

-- Grant access only to the customer's own data
GRANT USAGE ON SCHEMA public TO client_John_Doe;
GRANT SELECT ON rental TO client_John_Doe;
GRANT SELECT ON payment TO client_John_Doe;

-- Assuming the customer's ID is 123
SET ROLE client_John_Doe;

-- Select the customer's own data from the rental and payment tables
SELECT * FROM rental WHERE customer_id = 123;
SELECT * FROM payment WHERE customer_id = 123;

-- Reset the role
RESET ROLE;